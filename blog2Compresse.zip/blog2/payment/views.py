from django.shortcuts import render,redirect
import moncashify

def payment(request):
    Client_Id= '3fe5bb3adc74d2a621ad7dfedd0ad7be'
    Client_Secret='oHrr4tbnB1PH0uz6VQNUvXFUBAugbi8coj2wDIGNCg4jRXxtBNre4W6MDywf6VHn'

    moncash = moncashify.API(Client_Id, Client_Secret,debug=True)
    if request.method== 'POST':
        amount=request.POST.get('amount')
        
        if amount == 500:
            amount
        if amount == 1000:
            amount
        if amount == 2000:
            amount
        if amount == 4000:
            amount
        else:
            amount

        order_id = 'SH023'
        amount=float(amount)
       
        payment = moncash.payment(order_id, amount)
        return redirect(payment.redirect_url)
    return render(request, 'Donation/payment.html') 
